#include <iostream>
#include <math.h>
using namespace std;
int main()
{
int a;
int x;
int b;
int c;
int r;

cout<<"Este programa es para realizar una operacion cuadratica (ax^2+bx+c)\n";

cout<<"Por favor digite un valor para a (un numero entero)\n";
cin>>a;
cout<<"Por favor digite un valor para x (un numero entero)\n";
cin>>x;
cout<<"Por favor digite un valor para b (un numero entero)\n";
cin>>b;
cout<<"Por favor digite un valor para c (un numero entero)\n";
cin>>c;

r=(a*(pow(x,2))+(b*x))+c;

cout<<"El resultado de la operacion es: "<<r<<endl;


}
