#include <iostream>
using namespace std;

float suma (float x,float y)
{
return x+y;
}
float resta (float x,float y)
{
return x-y;
}
float multiplicacion (float x,float y)
{
return x*y;
}
float division (float x,float y)
{
return x/y;
}

int main ()
{
float x;
float y;
int opc;
cout<<"Este programa es para realizar una operacion (a eleccion del usuario)\n";
cout<<"ingrese el valor del primer numero \n";
cin>>x;
cout<<"ingrese el valor del segundo numero \n";
cin>>y;
cout<<"Seleccione su opcion\n";
cout<<"Opciones: \n";
cout<<"1. Suma \n";
cout<<"2. Resta \n";
cout<<"3. Multiplicacion \n";
cout<<"4. Division \n";
cin>>opc;
if(opc<=4 && opc>=1)
{
switch (opc)
{
case 1:
cout<<suma (x,y);
break;

case 2:
cout<<resta (x,y);
break;

case 3:
cout<<multiplicacion (x,y);
break;

case 4:
if(y!=0)
{
cout<<division (x,y);
   }
   else
   {
   cout<<x;
}
break;

}
}
else
{
cout<<"La opcion digitada no esta en la lista";
}


return 0;

}
