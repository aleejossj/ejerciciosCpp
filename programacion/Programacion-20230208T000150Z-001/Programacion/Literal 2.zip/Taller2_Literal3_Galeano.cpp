# include <iostream>
# include <math.h>
# include <iomanip>
# include <string>
using namespace std;
int num,i,cont,negativos,cero,positivo;
int main () 
{	
cout<<"Digite 10 numeros\n";
	
	for (i=1;i<=10;i++)
	{
		
		cin>>num;
		if(num<0)
		{
			negativos++;
		}
		else
		{
			if(num==0)
			{
				cero++;
			}
			else
			{
				if(num>0)
				{
					positivo++;
				}
			}
		}
	}
	cout<<"Las cantidades son:\n";
	cout<<"Negativos: "<<negativos<<endl;
	cout<<"En cero : "<<cero<<endl;
	cout<<"positivo: "<<positivo<<endl;
}	
	

