# include <iostream>
# include <math.h>
# include <iomanip>
# include <string>
using namespace std;

int main () 
{
	for(int x=2;x<=20;x++)
	{
    	int i;
    	for(i=2;i<=x-1;i++)
    	{
       
    	}

    	if( i==x )
        	cout<<x<<" Es primo \n";
	}
}