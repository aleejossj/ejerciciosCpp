# include <iostream>
# include <math.h>
# include <iomanip>
# include <string>
using namespace std;
int x = 0;
int y = 1;
int z = 0;
int main () 
{
	cout<<x<<endl;
	cout<<y<<endl;
	while (z<=1000)
	{
		z = x + y;
		x = y;
		y = z;
		cout<< z<<endl;
		z++;
	}
}
