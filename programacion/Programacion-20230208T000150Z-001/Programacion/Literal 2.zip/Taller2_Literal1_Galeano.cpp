#include <iostream>


using namespace std;
int x = 0;
int y = 1;
int z = 0;
int main() 
{	
	cout<<x<<endl;
	cout<<y<<endl;
	
	for(int z = 1; z <=1000; z++)
	{
		z = x + y;
		x = y;
		y = z;
		cout<< z<<endl;
	}
	
	
	return 0;
}