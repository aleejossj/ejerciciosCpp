# include <iostream>
# include <math.h>
# include <iomanip>
# include <string>
using namespace std;
int i,RA;
int main () 
{
	for (i=1;i<=50;i++)
	{
		RA=i+i;
		cout<<"La suma de "<< i << " + " << i<< " es: "<< RA <<endl;
	}

}