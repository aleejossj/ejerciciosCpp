#include <iostream>
#include<fstream>
#include<string.h>
using namespace std;
struct persona
{
    string nombre;
    string apellido;
    int edad;
    float altura;
    float peso;
    int cedula;

};
void funcion (persona persona)
{
	
    fstream app;
    app.open("Persona.csv",ios::app);
    app<<persona.nombre<<","<<persona.apellido<<","<<persona.edad<<","<<persona.altura<<","<<persona.peso<<","<<persona.cedula<<endl;
}
int main ()
{
	
    persona persona;
    int n;
    cout<<"Digite la cantidad de entradas de personas que quiere hacer\n";
    cin>>n;
    for(int i=1;i<=n;i++)
    {
    cout<<"Digite el nombre de la persona :"<<endl;
    cin>>persona.nombre;
    cout<<"Digite el apellido de la persona :"<<endl;
    cin>>persona.apellido;
    cout<<"Digite la edad de la persona :"<<endl;
    cin>>persona.edad;
    cout<<"Digite la altura de la persona (m):"<<endl;
    cin>>persona.altura;
    cout<<"Digite el peso de la persona (kg):"<<endl;
    cin>>persona.peso;
    cout<<"Digite la cedula de la persona :"<<endl;
    cin>>persona.cedula;
    system("cls");
    funcion (persona);
	cout<<endl;
	}
  


}
