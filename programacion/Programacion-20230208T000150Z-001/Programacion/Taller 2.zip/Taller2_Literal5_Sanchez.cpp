# include <iostream>
# include <math.h>
# include <iomanip>
# include <string>
using namespace std;

int main () 
{
	cout<<"Este programa es para mostrar los primero 20 numeros primos\n";
float n;
for(int a=1;a<=20;a++)
{
if(a/a==1 && a/1==a)
{
cout<<a<<endl;
}
}
}
