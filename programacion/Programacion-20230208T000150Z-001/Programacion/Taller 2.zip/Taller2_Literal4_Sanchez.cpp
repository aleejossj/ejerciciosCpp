# include <iostream>
# include <math.h>

using namespace std;
int c,s;
int main () 
{
	cout<<"Este programa es para realizar la suma de los primero 50 numeros enteros\n";
	for (c=1;c<=50;c++)
	{
		s=c+c;
		cout<<c<<"+"<<c<< " es: "<<s<<endl;
	}

}


