#include <iostream>
#include <stdlib.h>

using namespace std;
void funcion()
{
int matriz[3][3]={{2,4,6},{0,3,4},{9,7,10}},i,j,mayor=0;

cout<<"Matriz\n";
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
		cout<<" "<<matriz[i][j];
		}
		cout<<endl;
	}

mayor=matriz[0][0];
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
		if(mayor<matriz[i][j])
		{
			mayor=matriz[i][j];
		
		}
		}
	}
cout<<"El mayor valor es: "<<mayor<<endl;
}
int main()
{

funcion ();
}
